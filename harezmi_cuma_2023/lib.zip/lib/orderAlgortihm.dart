import 'package:harezmi_cuma_2023/req.dart';

Map tables = {
  "1" : {
    "orders" : {
      "names" : [],
      "prices" : [],
    },
    "onTable" : false,
  },
  "2" : {
    "orders" : {
      "names" : [],
      "prices" : [],
    },
    "onTable" : false,
  },
  "3" : {
    "orders" : {
      "names" : [],
      "prices" : [],
    },
    "onTable" : false,
  },
  "4" : {
    "orders" : {
      "names" : [],
      "prices" : [],
    },
    "onTable" : false,
  },
  "5" : {
    "orders" : {
      "names" : [],
      "prices" : [],
    },
    "onTable" : false,
  },
};